# Food Diano Client (React)

This is the React frontend for the Food Diano delivery app.

## Setup

- Run `setup.sh` (Linux/macOS) or `setup.bat` (Windows) to install dependencies.
- Start the app with `npm start`.
