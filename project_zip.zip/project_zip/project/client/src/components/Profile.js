import React, { useState, useEffect } from 'react';
import { getProfile, getOrders } from '../api';
import '../styles/Profile.css';

function Profile({ token, setToken }) {
  const [profile, setProfile] = useState(null);
  const [orders, setOrders] = useState([]);
  const [address, setAddress] = useState('');
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    getProfile(token).then(setProfile);
    getOrders(token).then(setOrders);
  }, [token]);

  const handleLogout = () => {
    setToken(null);
  };

  const saveAddress = () => {
    // In a real app, you would save this to the backend
    setProfile({ ...profile, address });
    setEditing(false);
  };

  if (!profile) return <div>Loading...</div>;

  return (
    <div className="profile">
      <div className="profile-section">
        <h2>Profile Information</h2>
        <div className="profile-info">
          <p><strong>Name:</strong> {profile.name}</p>
          <p><strong>Email:</strong> {profile.email}</p>
          <div className="address-section">
            <strong>Delivery Address:</strong>
            {editing ? (
              <div className="address-edit">
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Enter your delivery address"
                />
                <button onClick={saveAddress}>Save</button>
                <button onClick={() => setEditing(false)}>Cancel</button>
              </div>
            ) : (
              <div>
                <p>{profile.address || 'No address added'}</p>
                <button onClick={() => setEditing(true)}>
                  {profile.address ? 'Edit Address' : 'Add Address'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="orders-section">
        <h2>Order History</h2>
        {orders.length === 0 ? (
          <p>No orders yet</p>
        ) : (
          <div className="orders-list">
            {orders.map((order) => (
              <div key={order.id} className="order-card">
                <h3>Order #{order.id}</h3>
                <p>Status: {order.status}</p>
                <p>Date: {new Date(order.date).toLocaleString()}</p>
                <div className="order-items">
                  {order.items.map((item, index) => (
                    <div key={index} className="order-item">
                      <span>{item.name}</span>
                      <span>₹{item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <button onClick={handleLogout} className="logout-btn">
        Logout
      </button>
    </div>
  );
}

export default Profile;
