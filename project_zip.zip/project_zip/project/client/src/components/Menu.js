import React, { useState, useEffect } from 'react';
import { getRestaurants } from '../api';
import '../styles/Menu.css';

function Menu({ token, cart, setCart }) {
  const [restaurants, setRestaurants] = useState([]);

  useEffect(() => {
    getRestaurants().then(setRestaurants);
  }, []);

  const addToCart = (dish) => {
    setCart([...cart, dish]);
  };

  return (
    <div className="menu">
      <h2>Our Restaurants</h2>
      <div className="restaurants-grid">
        {restaurants.map((restaurant) => (
          <div key={restaurant.id} className="restaurant-card">
            <h3>{restaurant.name}</h3>
            <div className="dishes-grid">
              {restaurant.dishes.map((dish) => (
                <div key={dish.id} className="dish-card">
                  <img 
                    src={dish.imageUrl} 
                    alt={dish.name} 
                    className="dish-image"
                    onError={(e) => {
                      e.target.src = 'https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg';
                    }}
                  />
                  <h4>{dish.name}</h4>
                  <p>₹{dish.price}</p>
                  <button onClick={() => addToCart(dish)}>Add to Cart</button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Menu;
