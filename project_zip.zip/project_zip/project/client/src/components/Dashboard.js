import React, { useEffect, useState } from 'react';
import { getProfile, getRestaurants, placeOrder, getOrders } from '../api';

export default function Dashboard({ token, setToken }) {
  const [profile, setProfile] = useState(null);
  const [restaurants, setRestaurants] = useState([]);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    getProfile(token).then(setProfile);
    getRestaurants().then(setRestaurants);
    getOrders(token).then(setOrders);
  }, [token]);

  const addToCart = dish => setCart([...cart, dish]);
  const clearCart = () => setCart([]);

  const handleOrder = async () => {
    const res = await placeOrder(token, cart);
    setMessage(res.message);
    setOrders([...orders, res.order]);
    clearCart();
  };

  if (!profile) return <div>Loading...</div>;

  return (
    <div>
      <h2>Welcome, {profile.name}</h2>
      <button onClick={() => setToken(null)}>Logout</button>
      <h3>Restaurants</h3>
      {restaurants.map(r => (
        <div key={r.id}>
          <h4>{r.name}</h4>
          <ul>
            {r.dishes.map(d => (
              <li key={d.id}>
                {d.name} - ${d.price}
                <button onClick={() => addToCart(d)}>Add to Cart</button>
              </li>
            ))}
          </ul>
        </div>
      ))}
      <h3>Cart</h3>
      <ul>
        {cart.map((d, i) => <li key={i}>{d.name} - ${d.price}</li>)}
      </ul>
      {cart.length > 0 && <button onClick={handleOrder}>Pay</button>}
      <h3>Previous Orders</h3>
      <ul>
        {orders.map(o => (
          <li key={o.id}>Order #{o.id} - {o.status} - {new Date(o.date).toLocaleString()}</li>
        ))}
      </ul>
      {message && <div style={{color:'green'}}>{message}</div>}
    </div>
  );
}
