import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaShoppingCart, FaUser, FaUtensils } from 'react-icons/fa';
import '../styles/Navbar.css';

function Navbar({ cartCount }) {
  return (
    <nav className="navbar">
      <div className="nav-brand">
        <Link to="/" className="brand-name">Food Diano</Link>
      </div>
      <div className="nav-links">
        <Link to="/" className="nav-link">
          <FaUtensils /> Menu
        </Link>
        <Link to="/cart" className="nav-link">
          <FaShoppingCart /> Cart ({cartCount})
        </Link>
        <Link to="/profile" className="nav-link">
          <FaUser /> Profile
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;
