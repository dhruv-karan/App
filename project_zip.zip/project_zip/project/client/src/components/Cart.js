import React from 'react';
import { placeOrder } from '../api';
import '../styles/Cart.css';

function Cart({ token, cart, setCart }) {
  const totalAmount = cart.reduce((sum, item) => sum + item.price, 0);

  const handleCheckout = async () => {
    try {
      await placeOrder(token, cart);
      setCart([]);
      alert('Order placed successfully!');
    } catch (error) {
      alert('Failed to place order');
    }
  };

  const removeFromCart = (index) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  if (cart.length === 0) {
    return (
      <div className="cart empty-cart">
        <h2>Your Cart is Empty</h2>
        <p>Add some delicious dishes to get started!</p>
      </div>
    );
  }

  return (
    <div className="cart">
      <h2>Your Cart</h2>
      <div className="cart-items">
        {cart.map((item, index) => (
          <div key={index} className="cart-item">
            <img 
              src={item.imageUrl} 
              alt={item.name} 
            />
            <div className="item-details">
              <h3>{item.name}</h3>
              <p>₹{item.price}</p>
            </div>
            <button onClick={() => removeFromCart(index)} className="remove-btn">
              Remove
            </button>
          </div>
        ))}
      </div>
      <div className="cart-summary">
	    <h3>Total: ₹{totalAmount}</h3>
        <button onClick={handleCheckout} className="checkout-btn">
          Place Order
        </button>
      </div>
    </div>
  );
}

export default Cart;
