import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Menu from './components/Menu';
import Cart from './components/Cart';
import Profile from './components/Profile';
import Login from './components/Login';
import './styles/App.css';

function App() {
  const [token, setToken] = useState(null);
  const [cart, setCart] = useState([]);

  if (!token) {
    return (
      <div className="app">
        <h1 className="brand-name">Food Diano</h1>
        <Login setToken={setToken} />
      </div>
    );
  }

  return (
    <Router>
      <div className="app">
        <Navbar cartCount={cart.length} />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Menu token={token} cart={cart} setCart={setCart} />} />
            <Route path="/cart" element={<Cart token={token} cart={cart} setCart={setCart} />} />
            <Route path="/profile" element={<Profile token={token} setToken={setToken} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
