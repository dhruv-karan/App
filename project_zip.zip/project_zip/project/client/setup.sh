#!/bin/bash
# Setup script for client (React)
npm install
