const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || 'supersecretkey';
const User = require('./models/User');
const restaurants = [
  { 
    id: 1,
    name: 'Pizza Paradise',
    dishes: [
      { id: 1, name: 'Margherita Pizza', price: 299, imageUrl: 'https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg' },
      { id: 2, name: 'Paneer Tikka Pizza', price: 349, imageUrl: 'https://images.pexels.com/photos/803290/pexels-photo-803290.jpeg' },
      { id: 3, name: 'Chicken Supreme Pizza', price: 399, imageUrl: 'https://images.pexels.com/photos/1653877/pexels-photo-1653877.jpeg' }
    ]
  },
  {
    id: 2,
    name: 'The Royal Thali',
    dishes: [
      { id: 4, name: 'Special Veg Thali', price: 249, imageUrl: 'https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg' },
      { id: 5, name: 'Deluxe Thali', price: 299, imageUrl: 'https://images.pexels.com/photos/941869/pexels-photo-941869.jpeg' }
    ]
  },
  {
    id: 3,
    name: 'Biryani House',
    dishes: [
      { id: 6, name: 'Hyderabadi Chicken Biryani', price: 299, imageUrl: 'https://images.pexels.com/photos/1624487/pexels-photo-1624487.jpeg' },
      { id: 7, name: 'Veg Biryani', price: 249, imageUrl: 'https://images.pexels.com/photos/7394819/pexels-photo-7394819.jpeg' }
    ]
  },
  {
    id: 4,
    name: 'South Indian Delights',
    dishes: [
      { id: 8, name: 'Masala Dosa', price: 129, imageUrl: 'https://images.pexels.com/photos/5560763/pexels-photo-5560763.jpeg' },
      { id: 9, name: 'Idli Sambar', price: 99, imageUrl: 'https://images.pexels.com/photos/4331489/pexels-photo-4331489.jpeg' }
    ]
  },
  {
    id: 5,
    name: 'Chinese Wok',
    dishes: [
      { id: 10, name: 'Veg Hakka Noodles', price: 179, imageUrl: 'https://images.pexels.com/photos/1731535/pexels-photo-1731535.jpeg' },
      { id: 11, name: 'Chicken Manchurian', price: 249, imageUrl: 'https://images.pexels.com/photos/5409015/pexels-photo-5409015.jpeg' }
    ]
  },
  {
    id: 6,
    name: 'North Indian Kitchen',
    dishes: [
      { id: 12, name: 'Butter Chicken', price: 349, imageUrl: 'https://images.pexels.com/photos/7394813/pexels-photo-7394813.jpeg' },
      { id: 13, name: 'Paneer Butter Masala', price: 299, imageUrl: 'https://images.pexels.com/photos/8340688/pexels-photo-8340688.jpeg' }
    ]
  },
  {
    id: 7,
    name: 'Sweet Corner',
    dishes: [
      { id: 14, name: 'Gulab Jamun', price: 99, imageUrl: 'https://images.pexels.com/photos/7449105/pexels-photo-7449105.jpeg' },
      { id: 15, name: 'Rasgulla', price: 89, imageUrl: 'https://images.pexels.com/photos/7449122/pexels-photo-7449122.jpeg' }
    ]
  },
  {
    id: 8,
    name: 'Chaat Street',
    dishes: [
      { id: 16, name: 'Pani Puri', price: 79, imageUrl: 'https://images.pexels.com/photos/4449068/pexels-photo-4449068.jpeg' },
      { id: 17, name: 'Bhel Puri', price: 89, imageUrl: 'https://images.pexels.com/photos/4331490/pexels-photo-4331490.jpeg' }
    ]
  },
  {
    id: 9,
    name: 'Rolls & Wraps',
    dishes: [
      { id: 18, name: 'Paneer Kathi Roll', price: 159, imageUrl: 'https://images.pexels.com/photos/461198/pexels-photo-461198.jpeg' },
      { id: 19, name: 'Chicken Shawarma', price: 179, imageUrl: 'https://images.pexels.com/photos/6488626/pexels-photo-6488626.jpeg' }
    ]
  },
  {
    id: 10,
    name: 'Burger Boulevard',
    dishes: [
      { id: 20, name: 'Classic Veg Burger', price: 129, imageUrl: 'https://images.pexels.com/photos/1633578/pexels-photo-1633578.jpeg' },
      { id: 21, name: 'Chicken Cheese Burger', price: 179, imageUrl: 'https://images.pexels.com/photos/2702674/pexels-photo-2702674.jpeg' },
      { id: 22, name: 'Spicy Paneer Burger', price: 149, imageUrl: 'https://images.pexels.com/photos/3219483/pexels-photo-3219483.jpeg' }
    ]
  },
  {
    id: 11,
    name: 'Ice Cream Paradise',
    dishes: [
      { id: 23, name: 'Belgian Chocolate', price: 149, imageUrl: 'https://images.pexels.com/photos/1352281/pexels-photo-1352281.jpeg' },
      { id: 24, name: 'Butterscotch Sundae', price: 169, imageUrl: 'https://images.pexels.com/photos/1362534/pexels-photo-1362534.jpeg' }
    ]
  }
];

// Auth middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Login (create user if not exists)
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  let user = await User.findOne({ username });
  if (!user) {
    // Create user on first login
    user = new User({ username, password, profile: { name: username, email: `${username}@example.com` }, orders: [] });
    await user.save();
  }
  if (user.password !== password) return res.status(401).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ id: user._id, username: user.username }, JWT_SECRET);
  res.json({ token });
});

// Get profile
router.get('/profile', authenticateToken, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.sendStatus(404);
  res.json(user.profile);
});

// Get restaurants
router.get('/restaurants', (req, res) => {
  res.json(restaurants);
});

// Cart and order management
router.post('/order', authenticateToken, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.sendStatus(404);
  const { items } = req.body;
  const order = { items, status: 'Delivered', date: new Date() };
  user.orders.push(order);
  await user.save();
  res.json({ message: 'Order placed and delivered!', order });
});

// Get previous orders
router.get('/orders', authenticateToken, async (req, res) => {
  const user = await User.findById(req.user.id);
  if (!user) return res.sendStatus(404);
  res.json(user.orders);
});

module.exports = router;
