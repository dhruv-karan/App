#!/bin/bash
# Setup script for server (Node.js/Express)
npm install
