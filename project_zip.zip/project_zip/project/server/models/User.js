const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  items: [
    {
      id: Number,
      name: String,
      price: Number
    }
  ],
  status: String,
  date: Date
});

const userSchema = new mongoose.Schema({
  username: { type: String, unique: true },
  password: String,
  profile: {
    name: String,
    email: String
  },
  orders: [orderSchema]
});

module.exports = mongoose.model('User', userSchema);
