const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json());

const JWT_SECRET = process.env.JWT_SECRET || 'supersecretkey';

// Hardcoded users (for demo)
const users = [
  { id: 1, username: 'student1', password: 'pass1', profile: { name: 'Student One', email: 'student1@example.com' }, orders: [] },
  { id: 2, username: 'student2', password: 'pass2', profile: { name: 'Student Two', email: 'student2@example.com' }, orders: [] }
];

// Hardcoded restaurants and dishes
const restaurants = [
  { id: 1, name: 'Pizza Place', dishes: [ { id: 1, name: 'Margherita Pizza', price: 8 }, { id: 2, name: 'Pepperoni Pizza', price: 10 } ] },
  { id: 2, name: 'Burger Joint', dishes: [ { id: 3, name: 'Cheeseburger', price: 7 }, { id: 4, name: 'Veggie Burger', price: 6 } ] }
];

// MongoDB connection
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/fooddelivery', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});
mongoose.connection.on('connected', () => {
  console.log('MongoDB connected');
});
mongoose.connection.on('error', (err) => {
  console.error('MongoDB connection error:', err);
});

const routes = require('./routes');
app.use('/api', routes);

app.listen(5000, () => console.log('Server running on port 5000'));
