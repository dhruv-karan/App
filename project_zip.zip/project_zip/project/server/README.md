# Food Diano Server (Node.js/Express)

This is the Node.js/Express backend for the Food Diano delivery app.

## Setup

- Run `setup.sh` (Linux/macOS) or `setup.bat` (Windows) to install dependencies.
- Start the server with `npm start`.
